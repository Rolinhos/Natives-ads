/* ========== STORAGE SEGURO (sandbox / telemóvel) ========== */
const Store = (function(){
  let mode = 'memory', mem = {};
  function detect(){
    try {
      const k = '__nap_t';
      localStorage.setItem(k,'1'); localStorage.removeItem(k);
      mode = 'local'; return;
    } catch(e){}
    try {
      const k = '__nap_t';
      sessionStorage.setItem(k,'1'); sessionStorage.removeItem(k);
      mode = 'session'; return;
    } catch(e){}
    mode = 'memory';
  }
  detect();
  function rawGet(){
    if(mode==='local') try{ return JSON.parse(localStorage.getItem('nap_db')||'null'); }catch(e){return null}
    if(mode==='session') try{ return JSON.parse(sessionStorage.getItem('nap_db')||'null'); }catch(e){return null}
    return mem.db || null;
  }
  function rawSet(obj){
    const s = JSON.stringify(obj);
    if(mode==='local') try{ localStorage.setItem('nap_db',s); return; }catch(e){ mode='memory'; }
    if(mode==='session') try{ sessionStorage.setItem('nap_db',s); return; }catch(e){ mode='memory'; }
    mem.db = obj;
  }
  function load(){
    let d = rawGet();
    if(!d) d = { users:[], campaigns:[], txs:[], notifs:[], support:[], session:null, recoveries:[] };
    if(!d.recoveries) d.recoveries = [];
    return d;
  }
  function save(d){ rawSet(d); }
  return { load, save, mode: ()=>mode };
})();

const ADMIN_EMAIL = 'rolinhos18@gmail.com';
const ADMIN_PASS = 'Admin846495100';
const PAY = {
  'M-Pesa': { number:'846495100', name:'Lourinho Tuto Lourinho' },
  'e-Mola': { number:'865894107', name:'Lourinho Tuto Lourinho' }
};

const S = { user:null, supportMode:'bot', create:{} };

function uid(p){ return p+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,7); }
function money(v){ return (Number(v)||0).toLocaleString('pt-MZ',{minimumFractionDigits:0,maximumFractionDigits:2})+' MT'; }
function toast(m){ const d=document.createElement('div'); d.className='toast'; d.textContent=m; document.body.appendChild(d); setTimeout(()=>d.remove(),2800); }
function esc(s){ return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function statusLabel(s){ return ({pendente:'Pendente',active:'Ativa',paused:'Pausada',concluida:'Concluída',rejeitada:'Rejeitada'})[s]||s||'Pendente'; }

function db(){ return Store.load(); }
function saveDb(d){ Store.save(d); }

/* ========== AUTH ========== */
function hash(s){
  // simples (client-side) — para produção usaria backend
  let h=0; const str=String(s);
  for(let i=0;i<str.length;i++) h=((h<<5)-h)+str.charCodeAt(i)|0;
  return 'h'+Math.abs(h).toString(16)+'_'+str.length;
}

function ensureAdmin(){
  const d=db();
  let u=d.users.find(x=>(x.email||'').toLowerCase()===ADMIN_EMAIL);
  if(!u){
    u={ id:'u_admin', name:'Lourinho Tuto Lourinho', phone:'846495100', email:ADMIN_EMAIL, pass:hash(ADMIN_PASS), isAdmin:true, createdAt:new Date().toISOString() };
    d.users.push(u); saveDb(d);
  } else if(!u.isAdmin){ u.isAdmin=true; saveDb(d); }
  return u;
}

function login(identifier, password){
  identifier=String(identifier||'').trim();
  password=String(password||'');
  if(identifier.toLowerCase()===ADMIN_EMAIL && password===ADMIN_PASS){
    const u=ensureAdmin();
    const d=db(); d.session={userId:u.id}; saveDb(d);
    return u;
  }
  const d=db();
  const u=d.users.find(x=>x.email===identifier || x.phone===identifier || (x.email||'').toLowerCase()===identifier.toLowerCase());
  if(!u || u.pass!==hash(password)) throw new Error('Credenciais incorretas');
  d.session={userId:u.id}; saveDb(d);
  return u;
}

function register(name, phone, email, password){
  if(!name||!phone||!email||!password) throw new Error('Campos obrigatórios');
  if(password.length<6) throw new Error('Senha mínimo 6 caracteres');
  if(email.toLowerCase()===ADMIN_EMAIL) throw new Error('E-mail reservado');
  const d=db();
  if(d.users.some(u=>u.email===email||u.phone===phone)) throw new Error('Utilizador já existe');
  const u={ id:uid('u'), name, phone, email, pass:hash(password), isAdmin:false, createdAt:new Date().toISOString() };
  d.users.push(u); d.session={userId:u.id}; saveDb(d);
  return u;
}

function logout(){ const d=db(); d.session=null; saveDb(d); S.user=null; }

function currentUser(){
  const d=db();
  if(!d.session||!d.session.userId) return null;
  return d.users.find(u=>u.id===d.session.userId)||null;
}

function balance(userId){
  const d=db();
  const dep=d.txs.filter(t=>t.userId===userId&&t.type==='deposit'&&t.status==='confirmed').reduce((s,t)=>s+(Number(t.amount)||0),0);
  const spent=d.txs.filter(t=>t.userId===userId&&t.type==='campaign_payment'&&t.status==='confirmed').reduce((s,t)=>s+(Number(t.amount)||0),0);
  return Math.max(0, dep-spent);
}

function pushNotif(n){
  const d=db();
  d.notifs.unshift({ id:uid('n'), read:false, createdAt:new Date().toISOString(), ...n });
  saveDb(d);
}

// Orçamento da carteira em MT; CPC em USD. Taxa de referência para estimativas.
const USD_MZN = 64; // 1 USD ≈ 64 MT (referência)
const MIN_USD = 2; // mínimo para anunciar
const MIN_MT = MIN_USD * USD_MZN; // 128 MT
function moneyUsd(v){ return '$'+(Number(v)||0).toFixed(2).replace('.',',')+' USD'; }
function estimate(totalMt, cpcUsd){
  cpcUsd=Number(cpcUsd)||0.5; totalMt=Math.max(0,Number(totalMt)||0);
  const totalUsd = totalMt / USD_MZN;
  const clicks=cpcUsd>0?Math.floor(totalUsd/cpcUsd):0;
  return { clicks, visits:Math.floor(clicks*0.85), sales:Math.floor(clicks*0.02), impressions:clicks?Math.floor(clicks/0.025):0, totalUsd };
}

/* ========== UI HELPERS ========== */
function showModal(html){
  const r=document.getElementById('modalRoot');
  r.innerHTML='<div class="modal-bg"><div class="modal">'+html+'</div></div>';
  r.querySelector('.modal-bg').onclick=e=>{ if(e.target.classList.contains('modal-bg')) r.innerHTML=''; };
}
function closeModal(){ document.getElementById('modalRoot').innerHTML=''; }

function setAuthUI(){
  const ok=!!S.user;
  document.getElementById('menuBtn').classList.toggle('hide',!ok);
  document.getElementById('hdrRight').classList.toggle('hide',!ok);
  document.getElementById('adminLink').classList.toggle('hide',!(S.user&&S.user.isAdmin));
  if(ok) document.getElementById('hdrBal').textContent=money(balance(S.user.id));
}

/* ========== VIEWS ========== */
function viewLogin(){
  document.getElementById('main').innerHTML=`
  <div class="card">
    <div class="between"><div class="brand"><div class="logo">NA</div>Native Ads Pay</div><span class="chip">MT</span></div>
    <p class="muted" style="margin:8px 0">Faça login para continuar</p>
    <label class="field-label">E-mail ou telefone</label>
    <input id="loginId" placeholder="exemplo@gmail.com ou +258 84..." value=""/>
    <label class="field-label">Senha</label>
    <div class="pass-wrap"><input id="loginPass" type="password"/><button type="button" class="eye" id="eyeL">👁️</button></div>
    <div class="between" style="margin-top:10px"><span class="link" id="goReg">Criar conta</span><button class="btn" id="btnLogin">Entrar</button></div>
    <p style="margin-top:12px;text-align:center"><span class="link" id="goRecover">Esqueceu a senha?</span></p>
    <p class="err" id="loginErr"></p>
  </div>`;
  document.getElementById('eyeL').onclick=()=>{ const i=document.getElementById('loginPass'); i.type=i.type==='password'?'text':'password'; };
  document.getElementById('goReg').onclick=()=>location.hash='register';
  document.getElementById('goRecover').onclick=()=>location.hash='recover';
  document.getElementById('btnLogin').onclick=()=>{
    const err=document.getElementById('loginErr'); err.style.display='none';
    try{
      S.user=login(document.getElementById('loginId').value, document.getElementById('loginPass').value);
      setAuthUI(); toast('Login OK');
      location.hash=S.user.isAdmin?'admin':'dashboard';
    }catch(e){ err.style.display='block'; err.textContent=e.message; }
  };
}

function makeToken(){
  return Math.random().toString(36).slice(2)+Date.now().toString(36)+Math.random().toString(36).slice(2);
}

function viewRecover(){
  document.getElementById('main').innerHTML=`
  <div class="card">
    <div class="h1">Recuperar senha</div>
    <p class="muted" style="margin-bottom:10px">Introduza o e-mail da sua conta. Enviaremos um link para redefinir a senha.</p>
    <label class="field-label">E-mail</label>
    <input id="recEmail" type="email" placeholder="exemplo@gmail.com"/>
    <button class="btn full" id="btnRec" style="margin-top:8px">Enviar link de recuperação</button>
    <p class="muted" style="margin-top:12px">Lembra-se da senha? <span class="link" id="backLog">Voltar ao login</span></p>
    <p class="err" id="recErr"></p>
    <div id="recOk" class="hide" style="margin-top:12px"></div>
  </div>`;
  document.getElementById('backLog').onclick=()=>location.hash='login';
  document.getElementById('btnRec').onclick=()=>{
    const err=document.getElementById('recErr'); err.style.display='none';
    const email=document.getElementById('recEmail').value.trim().toLowerCase();
    if(!email||!email.includes('@')){ err.style.display='block'; err.textContent='Introduza um e-mail válido'; return; }
    const d=db();
    const user=d.users.find(u=>(u.email||'').toLowerCase()===email);
    const token=makeToken();
    const expires=Date.now()+1000*60*60*24; // 24 h
    const base=location.href.split('#')[0];
    const link=base+'#reset-'+token;
    if(user){
      d.recoveries=(d.recoveries||[]).filter(r=>r.email!==email || r.status==='used');
      d.recoveries.unshift({
        id: uid('r'),
        email,
        token,
        expires,
        userId: user.id,
        userName: user.name || email,
        userPhone: user.phone || '',
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      saveDb(d);
      pushNotif({
        title: 'Pedido de recuperação de senha',
        message: (user.name||'')+' ('+email+') pediu recuperação de senha.',
        type: 'info',
        forAdmin: true
      });
    }
    // Abre o app de e-mail no telemóvel/PC (não envia sozinho — o utilizador confirma o envio)
    const subject=encodeURIComponent('Native Ads Pay — Recuperar senha');
    const body=encodeURIComponent('Olá'+(user&&user.name?(' '+user.name):'')+',\n\nClique no link para redefinir a senha (válido 24h):\n\n'+link+'\n\nSe não pediu isto, ignore.\n\nNative Ads Pay');
    const mailto='mailto:'+encodeURIComponent(email)+'?subject='+subject+'&body='+body;
    // Usar <a> temporário evita bloqueios em alguns browsers
    const a=document.createElement('a'); a.href=mailto; a.style.display='none'; document.body.appendChild(a); a.click(); a.remove();

    document.getElementById('recOk').classList.remove('hide');
    document.getElementById('recOk').innerHTML=`
      <div class="card" style="background:#e8f8ef;border:1px solid #bbf7d0">
        <strong>Pedido registado</strong>
        <p class="muted" style="margin:8px 0">Se a conta existir, o administrador recebe o pedido e pode enviar-lhe o link.</p>
        <p class="muted" style="margin-bottom:8px">Também pode abrir o link directamente:</p>
        <button class="btn full" id="openReset">Abrir link de recuperação</button>
        <button class="btn secondary full" id="openMail" style="margin-top:8px">Abrir app de e-mail</button>
        <p class="muted" style="margin-top:8px;font-size:11px;word-break:break-all">${esc(link)}</p>
      </div>`;
    document.getElementById('openReset').onclick=()=>{ location.hash='reset-'+token; };
    document.getElementById('openMail').onclick=()=>{ window.location.href=mailto; };
    toast(user?'Pedido enviado — admin notificado':'Se o e-mail existir, o pedido foi registado');
  };
}

function viewReset(token){
  document.getElementById('main').innerHTML=`
  <div class="card">
    <div class="h1">Nova senha</div>
    <p class="muted" style="margin-bottom:10px">Defina uma nova senha para a sua conta.</p>
    <label class="field-label">Nova senha</label>
    <div class="pass-wrap"><input id="newPass" type="password"/><button type="button" class="eye" id="eyeN1">👁️</button></div>
    <label class="field-label">Confirmar senha</label>
    <div class="pass-wrap"><input id="newPass2" type="password"/><button type="button" class="eye" id="eyeN2">👁️</button></div>
    <button class="btn full" id="btnReset" style="margin-top:8px">Guardar nova senha</button>
    <p class="muted" style="margin-top:12px"><span class="link" id="backLog2">Voltar ao login</span></p>
    <p class="err" id="resetErr"></p>
  </div>`;
  document.getElementById('eyeN1').onclick=()=>{ const i=document.getElementById('newPass'); i.type=i.type==='password'?'text':'password'; };
  document.getElementById('eyeN2').onclick=()=>{ const i=document.getElementById('newPass2'); i.type=i.type==='password'?'text':'password'; };
  document.getElementById('backLog2').onclick=()=>location.hash='login';
  document.getElementById('btnReset').onclick=()=>{
    const err=document.getElementById('resetErr'); err.style.display='none';
    const p1=document.getElementById('newPass').value;
    const p2=document.getElementById('newPass2').value;
    if(p1.length<6){ err.style.display='block'; err.textContent='Senha mínimo 6 caracteres'; return; }
    if(p1!==p2){ err.style.display='block'; err.textContent='Senhas não coincidem'; return; }
    const d=db();
    const rec=(d.recoveries||[]).find(r=>r.token===token && r.expires>Date.now());
    if(!rec){ err.style.display='block'; err.textContent='Link inválido ou expirado. Peça um novo.'; return; }
    const u=d.users.find(x=>x.id===rec.userId);
    if(!u){ err.style.display='block'; err.textContent='Utilizador não encontrado'; return; }
    u.pass=hash(p1);
    d.recoveries=(d.recoveries||[]).map(r=>{
      if(r.token===token) return Object.assign({}, r, { status:'used', usedAt:new Date().toISOString() });
      return r;
    });
    saveDb(d);
    pushNotif({ title:'Senha redefinida', message:(u.name||u.email)+' redefiniu a senha.', type:'info', forAdmin:true });
    toast('Senha atualizada — faça login');
    location.hash='login';
  };
}

function viewRegister(){
  document.getElementById('main').innerHTML=`
  <div class="card"><div class="h1">Criar conta</div>
  <label class="field-label">Nome</label><input id="rName"/>
  <label class="field-label">Telefone</label><input id="rPhone" placeholder="+258 84..."/>
  <label class="field-label">E-mail</label><input id="rEmail" type="email"/>
  <label class="field-label">Senha</label><div class="pass-wrap"><input id="rPass" type="password"/><button type="button" class="eye" id="eyeR">👁️</button></div>
  <label class="field-label">Confirmar senha</label><input id="rPass2" type="password"/>
  <label class="muted"><input type="checkbox" id="rTerms"/> Aceito os termos</label>
  <button class="btn full" id="btnReg" style="margin-top:10px">Criar conta</button>
  <p class="muted" style="margin-top:10px">Já tem conta? <span class="link" id="goLog">Entrar</span></p>
  <p class="err" id="regErr"></p></div>`;
  document.getElementById('eyeR').onclick=()=>{ const i=document.getElementById('rPass'); i.type=i.type==='password'?'text':'password'; };
  document.getElementById('goLog').onclick=()=>location.hash='login';
  document.getElementById('btnReg').onclick=()=>{
    const err=document.getElementById('regErr'); err.style.display='none';
    if(!document.getElementById('rTerms').checked){ err.style.display='block'; err.textContent='Aceite os termos'; return; }
    if(document.getElementById('rPass').value!==document.getElementById('rPass2').value){ err.style.display='block'; err.textContent='Senhas não coincidem'; return; }
    try{
      S.user=register(document.getElementById('rName').value.trim(), document.getElementById('rPhone').value.trim(), document.getElementById('rEmail').value.trim(), document.getElementById('rPass').value);
      setAuthUI(); toast('Conta criada'); location.hash='dashboard';
    }catch(e){ err.style.display='block'; err.textContent=e.message; }
  };
}

function viewDashboard(){
  const camps=db().campaigns.filter(c=>c.userId===S.user.id);
  const bal=balance(S.user.id);
  const spent=db().txs.filter(t=>t.userId===S.user.id&&t.type==='campaign_payment'&&t.status==='confirmed').reduce((s,t)=>s+(Number(t.amount)||0),0);
  const active=camps.filter(c=>['active','pendente'].includes(c.status)).length;
  document.getElementById('main').innerHTML=`
  <div class="card between"><div><div class="h1">Olá, ${esc((S.user.name||'').split(' ')[0])}</div><div class="muted">Resumo da conta</div></div><div class="big">${money(bal)}</div></div>
  <div class="grid">
    <div class="card"><div class="muted">Saldo</div><div class="big">${money(bal)}</div><button class="btn warn" id="goWallet" style="margin-top:8px">Adicionar saldo</button></div>
    <div class="card"><div class="muted">Gasto</div><div class="big">${money(spent)}</div></div>
    <div class="card"><div class="muted">Ativas/Pendentes</div><div class="big">${active}</div></div>
    <div class="card"><div class="muted">Total campanhas</div><div class="big">${camps.length}</div></div>
  </div>
  <div class="card"><div class="between"><div class="h2">Campanhas recentes</div><button class="btn warn" id="goCreate">+ Criar</button></div><div id="recent"></div></div>`;
  document.getElementById('goWallet').onclick=()=>location.hash='wallet';
  document.getElementById('goCreate').onclick=()=>location.hash='create';
  const recent=document.getElementById('recent');
  if(!camps.length) recent.innerHTML='<p class="muted">Ainda sem campanhas.</p>';
  else camps.slice(0,5).forEach(c=>{
    recent.innerHTML+=`<div class="between" style="padding:8px 0;border-bottom:1px solid #f0f0f0"><div><strong>${esc(c.name)}</strong><div class="muted">${(c.platforms||[]).join(', ')}</div></div><span class="badge ${c.status}">${statusLabel(c.status)}</span></div>`;
  });
  setAuthUI();
}

function viewWallet(){
  const bal=balance(S.user.id);
  document.getElementById('main').innerHTML=`
  <div class="card"><div class="h2">Carteira</div><div class="muted">Saldo disponível</div><div class="big">${money(bal)}</div>
  <button class="btn warn" id="addFunds" style="margin-top:12px">Adicionar saldo</button>
  <p class="muted" style="margin-top:12px">Pague via M-Pesa ou e-Mola e anexe o screenshot. O administrador aprova o depósito.</p></div>`;
  document.getElementById('addFunds').onclick=openDeposit;
  setAuthUI();
}

function openDeposit(){
  showModal(`<div class="between"><strong>Adicionar saldo</strong><button class="icon-btn" id="xM">✕</button></div>
  <label class="field-label">Valor (MT)</label><input type="number" id="amt" value="500" min="1"/>
  <div class="row" style="margin:10px 0"><button class="btn" id="mMpesa">M-Pesa</button><button class="btn secondary" id="mEmola">e-Mola</button></div>
  <div id="payBox"></div>`);
  document.getElementById('xM').onclick=closeModal;
  let method=null, proof=null;
  function show(m){
    method=m; const info=PAY[m]; proof=null;
    document.getElementById('payBox').innerHTML=`
    <div class="card" style="background:#f6f9ff"><div class="h3">Pague para ${m}</div>
    <div><strong>Número:</strong> <span style="font-size:18px;font-weight:800">${esc(info.number)}</span></div>
    <div><strong>Nome:</strong> ${esc(info.name)}</div>
    <p class="muted" style="margin:8px 0">Tire screenshot da confirmação e anexe.</p>
    <input type="file" id="proof" accept="image/*"/>
    <div id="prev"></div>
    <button class="btn full" id="sendDep" style="margin-top:10px">Enviar para aprovação</button></div>`;
    document.getElementById('proof').onchange=e=>{
      const f=e.target.files[0]; if(!f) return;
      if(f.size>3e6){ toast('Máx 3MB'); return; }
      const r=new FileReader();
      r.onload=ev=>{ proof=ev.target.result; document.getElementById('prev').innerHTML=`<img class="proof" src="${proof}"/>`; };
      r.readAsDataURL(f);
    };
    document.getElementById('sendDep').onclick=()=>{
      const amount=Number(document.getElementById('amt').value);
      if(!amount||amount<1){ toast('Valor inválido'); return; }
      if(!proof){ toast('Anexe o screenshot'); return; }
      const d=db();
      const tx={ id:uid('t'), userId:S.user.id, type:'deposit', method, amount, reference:(method==='M-Pesa'?'mpesa_':'emola_')+Date.now(), status:'pending', proofData:proof, payNumber:info.number, payName:info.name, createdAt:new Date().toISOString() };
      d.txs.unshift(tx); saveDb(d);
      pushNotif({ title:'Depósito enviado', message:`Depósito de ${amount} MT via ${method} aguarda aprovação.`, type:'info', forUserId:S.user.id });
      pushNotif({ title:'Novo depósito pendente', message:`${S.user.name}: ${amount} MT via ${method}`, type:'info', forAdmin:true });
      closeModal(); toast('Depósito enviado — aguarda aprovação'); location.hash='transactions';
    };
  }
  document.getElementById('mMpesa').onclick=()=>show('M-Pesa');
  document.getElementById('mEmola').onclick=()=>show('e-Mola');
}

function viewTransactions(){
  const list=db().txs.filter(t=>t.userId===S.user.id);
  let html='<div class="card"><div class="h2">Transações</div>';
  if(!list.length) html+='<p class="muted">Nenhuma</p>';
  list.forEach(t=>{
    const st=t.status==='pending'?'Aguarda aprovação':t.status==='rejected'?'Rejeitado':t.status==='confirmed'?'Confirmado':t.status;
    html+=`<div class="between" style="padding:8px 0;border-bottom:1px solid #f0f0f0"><div><strong>${t.type==='deposit'?'Depósito':'Pagamento'}</strong><div class="muted">${esc(t.method)} · ${esc(t.reference)}</div></div><div style="text-align:right"><strong>${money(t.amount)}</strong><div class="muted">${st}</div></div></div>`;
  });
  html+='</div>';
  document.getElementById('main').innerHTML=html;
}

function viewCampaigns(){
  const list=db().campaigns.filter(c=>c.userId===S.user.id);
  let html='<div class="card"><div class="h2">Minhas campanhas</div>';
  if(!list.length) html+='<p class="muted">Sem campanhas. <span class="link" onclick="location.hash=\'create\'">Criar</span></p>';
  list.forEach(c=>{
    const cr=c.creative||{};
    html+=`<div class="card"><div class="between"><div><strong>${esc(c.name)}</strong>
      <div class="muted">${esc(c.objective||'')} · ${(c.platforms||[]).join(', ')} · ${money(c.totalBudget)}</div></div>
      <span class="badge ${c.status}">${statusLabel(c.status)}</span></div>
    <div class="muted" style="margin-top:6px">CPC ${moneyUsd(c.cpc)} · ${esc((c.locations||[]).slice(0,2).join(', '))} · ${esc(cr.format||'')} · CTA: ${esc(cr.cta||'—')}</div>
    <div class="muted">Est. cliques ${c.estimatedClicks||0} · visitas ${c.estimatedVisits||0}</div></div>`;
  });
  html+='</div>';
  document.getElementById('main').innerHTML=html;
}

function viewCreate(){
  const STEPS = [
    { id:'objetivo', label:'1. Objetivo' },
    { id:'nome', label:'2. Nome' },
    { id:'plataformas', label:'3. Plataformas' },
    { id:'local', label:'4. Local' },
    { id:'publico', label:'5. Público' },
    { id:'interesses', label:'6. Interesses' },
    { id:'colocacoes', label:'7. Onde mostrar' },
    { id:'orcamento', label:'8. Orçamento' },
    { id:'anuncio', label:'9. Anúncio' },
    { id:'revisao', label:'10. Revisar' }
  ];
  const OBJECTIVES = [
    { id:'sales', title:'Vendas', desc:'Vender produtos ou serviços' },
    { id:'messages', title:'Mensagens', desc:'Clientes a escrever no WhatsApp / Messenger' },
    { id:'traffic', title:'Visitas ao site', desc:'Levar pessoas ao seu site ou página' },
    { id:'awareness', title:'Dar a conhecer', desc:'Mais pessoas a ver a sua marca' },
    { id:'engagement', title:'Curtidas e comentários', desc:'Mais interação nas publicações' },
    { id:'leads', title:'Contactos (leads)', desc:'Recolher telefone ou e-mail de clientes' }
  ];
  const PLATFORMS = ['Facebook','Instagram','WhatsApp','TikTok','Google','Todas'];
  const LOCATIONS = ['Todo Moçambique','Maputo Cidade','Matola','Beira','Nampula','Pemba','Quelimane','Tete','Inhambane','Chimoio','Xai-Xai','Nacala'];
  const INTERESTS = ['Negócios','Comida','Moda','Telemóveis','Educação','Saúde','Desporto','Música','Beleza','Carros','Finanças','Agricultura','Construção','Viagens'];
  const PLACEMENTS_AUTO = 'Automático (melhor desempenho)';
  const PLACEMENTS = ['Feed Facebook','Stories Facebook','Feed Instagram','Stories Instagram','Reels','WhatsApp Status','TikTok','Google'];
  const CTAS = ['Saiba mais','Comprar agora','Enviar mensagem','Ligar agora','Inscrever-se','Ver produto','Contactar'];

  if(!S.create || !S.create._wizard){
    S.create = {
      _wizard:true, step:0,
      objective:'sales', objectiveTitle:'Vendas',
      name:'', specialCategory:'Nenhuma',
      platforms:[], placements:[], placementMode:'auto',
      gender:'Todos', minAge:18, maxAge:45, locations:['Todo Moçambique'], interests:[], language:'Português',
      budgetType:'daily', dailyBudget:Math.max(50, Math.ceil(MIN_MT/7)), lifetimeBudget:MIN_MT, days:7, cpc:0.5,
      startDate:'', endDate:'',
      format:'Imagem', primaryText:'', headline:'', description:'', cta:'Saiba mais',
      websiteUrl:'', mediaNote:'', whatsapp:''
    };
  }
  const W = S.create;

  function totalBudget(){ return Math.max(0, (Number(W.dailyBudget)||0) * (Number(W.days)||0)); }

  function renderSteps(){
    return `<div class="steps">${STEPS.map((s,i)=>`<span class="step-dot ${i===W.step?'on':(i<W.step?'done':'')}">${s.label}</span>`).join('')}</div>
      <p class="muted" style="margin-bottom:10px">Passo ${W.step+1} de ${STEPS.length} — preencha com calma</p>`;
  }

  function show(){
    let body='';
    if(W.step===0){
      body=`<div class="h2">Qual é o objetivo?</div>
        <p class="muted" style="margin-bottom:8px">Escolha o que quer alcançar com este anúncio.</p>
        <div id="objList"></div>`;
    } else if(W.step===1){
      body=`<div class="h2">Nome da campanha</div>
        <p class="muted" style="margin-bottom:8px">Um nome simples para si identificar depois.</p>
        <label class="field-label">Nome</label>
        <input id="cName" value="${esc(W.name)}" placeholder="Ex: Promo sabão Maputo"/>
        <label class="field-label">Categoria especial (se aplicar)</label>
        <select id="cCat">
          <option ${W.specialCategory==='Nenhuma'?'selected':''}>Nenhuma</option>
          <option ${W.specialCategory==='Crédito'?'selected':''}>Crédito</option>
          <option ${W.specialCategory==='Emprego'?'selected':''}>Emprego</option>
          <option ${W.specialCategory==='Habitação'?'selected':''}>Habitação</option>
          <option ${W.specialCategory==='Política / social'?'selected':''}>Política / social</option>
        </select>`;
    } else if(W.step===2){
      body=`<div class="h2">Onde quer anunciar?</div>
        <p class="muted" style="margin-bottom:8px">Pode escolher uma ou várias redes.</p>
        <div id="plats" class="row"></div>`;
    } else if(W.step===3){
      body=`<div class="h2">Onde estão os seus clientes?</div>
        <p class="muted" style="margin-bottom:8px">Toque nas cidades ou em Todo Moçambique.</p>
        <div id="locs" class="row"></div>`;
    } else if(W.step===4){
      body=`<div class="h2">Quem deve ver o anúncio?</div>
        <label class="field-label">Idade (dos … aos … anos)</label>
        <div class="row"><input id="minAge" type="number" min="13" max="65" value="${W.minAge}" style="flex:1"/><span style="padding:0 6px">até</span><input id="maxAge" type="number" min="13" max="65" value="${W.maxAge}" style="flex:1"/></div>
        <label class="field-label">Género</label>
        <select id="cGender">
          <option ${W.gender==='Todos'?'selected':''}>Todos</option>
          <option ${W.gender==='Homens'?'selected':''}>Homens</option>
          <option ${W.gender==='Mulheres'?'selected':''}>Mulheres</option>
        </select>
        <label class="field-label">Idioma</label>
        <select id="cLang"><option>Português</option><option>Inglês</option><option>Português e Inglês</option></select>`;
    } else if(W.step===5){
      body=`<div class="h2">Interesses (opcional)</div>
        <p class="muted" style="margin-bottom:8px">Toque nos temas que o seu cliente gosta. Pode saltar se não tiver a certeza.</p>
        <div id="ints" class="row"></div>`;
    } else if(W.step===6){
      body=`<div class="h2">Onde mostrar o anúncio</div>
        <p class="muted" style="margin-bottom:8px">Recomendamos Automático — o sistema escolhe os melhores sítios.</p>
        <select id="placeMode">
          <option value="auto" ${W.placementMode==='auto'?'selected':''}>Automático (recomendado)</option>
          <option value="manual" ${W.placementMode==='manual'?'selected':''}>Eu escolho</option>
        </select>
        <div id="placeBox"></div>`;
    } else if(W.step===7){
      body=`<div class="h2">Orçamento</div>
        <p class="muted" style="margin-bottom:8px">Mínimo para anunciar: <strong>${moneyUsd(MIN_USD)}</strong> ≈ <strong>${money(MIN_MT)}</strong></p>
        <label class="field-label">Quanto por dia (MT)?</label>
        <input type="number" id="cDaily" value="${W.dailyBudget}" min="1"/>
        <label class="field-label">Durante quantos dias?</label>
        <input type="number" id="cDays" value="${W.days}" min="1"/>
        <label class="field-label">Data de início (opcional)</label>
        <input type="date" id="cStart" value="${W.startDate||''}"/>
        <label class="field-label">Data de fim (opcional)</label>
        <input type="date" id="cEnd" value="${W.endDate||''}"/>
        <label class="field-label">CPC — cost per click (USD)</label>
        <select id="cCpc">
          <option value="0.30" ${Number(W.cpc)===0.3?'selected':''}>$0.30 USD</option>
          <option value="0.50" ${Number(W.cpc)===0.5?'selected':''}>$0.50 USD</option>
          <option value="0.75" ${Number(W.cpc)===0.75?'selected':''}>$0.75 USD</option>
          <option value="1.00" ${Number(W.cpc)===1?'selected':''}>$1.00 USD</option>
        </select>
        <div id="est" class="card" style="background:#f6f9ff;margin-top:8px"></div>`;
    } else if(W.step===8){
      body=`<div class="h2">O seu anúncio</div>
        <p class="muted" style="margin-bottom:8px">Escreva de forma clara, como se falasse com um cliente.</p>
        <label class="field-label">Formato</label>
        <select id="cFormat"><option>Imagem</option><option>Vídeo</option><option>Carrossel</option><option>Stories</option></select>
        <label class="field-label">Texto do anúncio</label>
        <textarea id="cPrimary" placeholder="Ex: Promoção esta semana em Maputo. Entregas em todo o país.">${esc(W.primaryText)}</textarea>
        <label class="field-label">Título curto</label>
        <input id="cHead" value="${esc(W.headline)}" placeholder="Ex: Oferta especial hoje"/>
        <label class="field-label">Descrição (opcional)</label>
        <input id="cDesc" value="${esc(W.description)}" placeholder="Ex: Stock limitado"/>
        <label class="field-label">Botão (CTA)</label>
        <select id="cCta">${CTAS.map(c=>`<option ${W.cta===c?'selected':''}>${c}</option>`).join('')}</select>
        <label class="field-label">Link do site ou Facebook (opcional)</label>
        <input id="cUrl" value="${esc(W.websiteUrl)}" placeholder="https://exemplo.com"/>
        <label class="field-label">WhatsApp para contacto (opcional)</label>
        <input id="cWa" value="${esc(W.whatsapp||'')}" placeholder="+258 84 000 0000"/>
        <label class="field-label">Nota sobre a foto/vídeo</label>
        <input id="cMedia" value="${esc(W.mediaNote)}" placeholder="Ex: Foto do produto na loja"/>`;
    } else {
      const total = totalBudget();
      const e = estimate(total, W.cpc);
      const okMin = total >= MIN_MT;
      body=`<div class="h2">Rever e publicar</div>
        <div class="card" style="background:#f8fafc">
          <div class="between"><span class="muted">Objetivo</span><strong>${esc(W.objectiveTitle)}</strong></div>
          <div class="between"><span class="muted">Nome</span><strong>${esc(W.name||'—')}</strong></div>
          <div class="between"><span class="muted">Redes</span><strong>${esc((W.platforms||[]).join(', ')||'—')}</strong></div>
          <div class="between"><span class="muted">Local</span><strong>${esc((W.locations||[]).join(', '))}</strong></div>
          <div class="between"><span class="muted">Público</span><strong>${esc(W.gender)}, ${W.minAge}–${W.maxAge} anos</strong></div>
          <div class="between"><span class="muted">Interesses</span><strong>${esc((W.interests||[]).join(', ')||'Qualquer')}</strong></div>
          <div class="between"><span class="muted">Onde mostrar</span><strong>${W.placementMode==='auto'?'Automático':esc((W.placements||[]).join(', ')||'—')}</strong></div>
          <div class="between"><span class="muted">Orçamento</span><strong>${money(total)} · CPC $ ${Number(W.cpc).toFixed(2)} USD</strong></div>
          <div class="between"><span class="muted">Anúncio</span><strong>${esc(W.format)} · ${esc(W.cta)}</strong></div>
          <div class="between"><span class="muted">WhatsApp</span><strong>${esc(W.whatsapp||'—')}</strong></div>
        </div>
        <div class="card" style="background:#f6f9ff;margin-top:8px">
          <strong>Estimativa</strong>
          <div class="row" style="margin-top:8px">
            <span class="chip">Cliques: ${e.clicks}</span><span class="chip">Visitas: ${e.visits}</span>
            <span class="chip">Vendas: ${e.sales}</span><span class="chip">Impressões: ${e.impressions}</span>
          </div>
          <p class="muted" style="margin-top:8px">Saldo: ${money(balance(S.user.id))} · Mínimo: ${money(MIN_MT)} ($ ${MIN_USD} USD)</p>
          ${okMin?'':'<p style="color:var(--danger);margin-top:6px">Orçamento abaixo do mínimo de $2 USD.</p>'}
          <p class="muted">A campanha fica <strong>pendente</strong> até o administrador aprovar.</p>
        </div>`;
    }

    const nextLabel = W.step===STEPS.length-1 ? 'Publicar campanha' : 'Continuar →';
    document.getElementById('main').innerHTML = `<div class="card">${renderSteps()}${body}
      <div class="wizard-nav">
        ${W.step>0?'<button class="btn secondary" id="wBack">← Voltar</button>':''}
        <button class="btn" id="wNext" style="flex:1">${nextLabel}</button>
      </div></div>`;

    if(W.step===0){
      const list=document.getElementById('objList');
      OBJECTIVES.forEach(o=>{
        const el=document.createElement('div');
        el.className='obj-card'+(W.objective===o.id?' sel':'');
        el.innerHTML=`<strong>${esc(o.title)}</strong><span class="muted">${esc(o.desc)}</span>`;
        el.onclick=()=>{ W.objective=o.id; W.objectiveTitle=o.title; show(); };
        list.appendChild(el);
      });
    }
    if(W.step===2){
      const plats=document.getElementById('plats');
      PLATFORMS.forEach(p=>{
        const el=document.createElement('div'); el.className='platform'+(W.platforms.includes(p)?' sel':''); el.textContent=p;
        el.onclick=()=>{
          if(p==='Todas'){ W.platforms=W.platforms.includes('Todas')?[]:['Todas']; }
          else {
            W.platforms=W.platforms.filter(x=>x!=='Todas');
            if(W.platforms.includes(p)) W.platforms=W.platforms.filter(x=>x!==p); else W.platforms.push(p);
          }
          show();
        };
        plats.appendChild(el);
      });
    }
    if(W.step===3){
      const locs=document.getElementById('locs');
      LOCATIONS.forEach(p=>{
        const el=document.createElement('div'); el.className='platform'+(W.locations.includes(p)?' sel':''); el.textContent=p;
        el.onclick=()=>{
          if(p==='Todo Moçambique'){ W.locations=['Todo Moçambique']; }
          else {
            W.locations=W.locations.filter(x=>x!=='Todo Moçambique');
            if(W.locations.includes(p)) W.locations=W.locations.filter(x=>x!==p); else W.locations.push(p);
            if(!W.locations.length) W.locations=['Todo Moçambique'];
          }
          show();
        };
        locs.appendChild(el);
      });
    }
    if(W.step===5){
      const ints=document.getElementById('ints');
      INTERESTS.forEach(p=>{
        const el=document.createElement('div'); el.className='platform'+(W.interests.includes(p)?' sel':''); el.textContent=p;
        el.onclick=()=>{ if(W.interests.includes(p)) W.interests=W.interests.filter(x=>x!==p); else W.interests.push(p); show(); };
        ints.appendChild(el);
      });
    }
    if(W.step===6){
      const box=document.getElementById('placeBox');
      const mode=document.getElementById('placeMode');
      function renderPlaces(){
        W.placementMode=mode.value;
        if(mode.value==='auto'){
          box.innerHTML='<p class="muted" style="margin-top:8px">O sistema coloca o anúncio onde tiver melhores resultados.</p>';
        } else {
          box.innerHTML='<div id="plList" class="row" style="margin-top:8px"></div>';
          const pl=document.getElementById('plList');
          PLACEMENTS.forEach(p=>{
            const el=document.createElement('div'); el.className='platform'+(W.placements.includes(p)?' sel':''); el.textContent=p;
            el.onclick=()=>{ if(W.placements.includes(p)) W.placements=W.placements.filter(x=>x!==p); else W.placements.push(p); el.classList.toggle('sel'); };
            pl.appendChild(el);
          });
        }
      }
      mode.onchange=renderPlaces; renderPlaces();
    }
    if(W.step===7){
      function calc(){
        const daily=Number(document.getElementById('cDaily').value)||0;
        const days=Number(document.getElementById('cDays').value)||0;
        const cpc=Number(document.getElementById('cCpc').value)||0.5;
        const total=daily*days;
        const e=estimate(total,cpc);
        const ok=total>=MIN_MT;
        document.getElementById('est').innerHTML=`<strong>Total ${money(total)}</strong> · CPC $ ${cpc.toFixed(2)} USD
          <div class="muted" style="margin-top:4px">≈ $ ${e.totalUsd.toFixed(2)} USD (1 USD = ${USD_MZN} MT)</div>
          <div class="row" style="margin-top:8px">
          <span class="chip">Clicks: ${e.clicks}</span><span class="chip">Visits: ${e.visits}</span>
          <span class="chip">Sales: ${e.sales}</span><span class="chip">Impressions: ${e.impressions}</span></div>
          ${ok?'<p class="muted" style="margin-top:6px;color:var(--ok)">✓ Acima do mínimo ($2 USD)</p>':'<p style="margin-top:6px;color:var(--danger)">Abaixo do mínimo: precisa de pelo menos '+money(MIN_MT)+'</p>'}`;
      }
      ['cDaily','cDays','cCpc'].forEach(id=>document.getElementById(id).oninput=calc); calc();
    }

    const back=document.getElementById('wBack');
    if(back) back.onclick=()=>{ saveStepFields(); W.step--; show(); };
    document.getElementById('wNext').onclick=()=>{
      if(!saveStepFields()) return;
      if(W.step<STEPS.length-1){ W.step++; show(); return; }
      publish();
    };
  }

  function saveStepFields(){
    if(W.step===0){
      if(!W.objective){ toast('Escolha um objetivo'); return false; }
    }
    if(W.step===1){
      const name=(document.getElementById('cName')&&document.getElementById('cName').value||'').trim();
      if(name.length<3){ toast('Escreva um nome com pelo menos 3 letras'); return false; }
      W.name=name;
      W.specialCategory=document.getElementById('cCat').value;
    }
    if(W.step===2){
      if(!W.platforms.length){ toast('Escolha pelo menos uma plataforma'); return false; }
    }
    if(W.step===3){
      if(!W.locations.length){ toast('Escolha a localização'); return false; }
    }
    if(W.step===4){
      W.minAge=Number(document.getElementById('minAge').value)||18;
      W.maxAge=Number(document.getElementById('maxAge').value)||45;
      if(W.minAge>W.maxAge){ toast('Idade inválida'); return false; }
      W.gender=document.getElementById('cGender').value;
      W.language=document.getElementById('cLang').value;
    }
    if(W.step===6){
      W.placementMode=document.getElementById('placeMode').value;
      if(W.placementMode==='manual' && !W.placements.length){ toast('Escolha onde mostrar ou use Automático'); return false; }
    }
    if(W.step===7){
      W.dailyBudget=Number(document.getElementById('cDaily').value)||0;
      W.days=Number(document.getElementById('cDays').value)||1;
      W.cpc=Number(document.getElementById('cCpc').value)||0.5;
      W.startDate=document.getElementById('cStart').value;
      W.endDate=document.getElementById('cEnd').value;
      W.lifetimeBudget=W.dailyBudget*W.days;
      if(W.dailyBudget<1||W.days<1){ toast('Orçamento inválido'); return false; }
      if(totalBudget()<MIN_MT){ toast('Mínimo para anunciar: $2 USD ('+money(MIN_MT)+')'); return false; }
    }
    if(W.step===8){
      W.format=document.getElementById('cFormat').value;
      W.primaryText=document.getElementById('cPrimary').value.trim();
      W.headline=document.getElementById('cHead').value.trim();
      W.description=document.getElementById('cDesc').value.trim();
      W.cta=document.getElementById('cCta').value;
      W.websiteUrl=document.getElementById('cUrl').value.trim();
      W.whatsapp=document.getElementById('cWa').value.trim();
      W.mediaNote=document.getElementById('cMedia').value.trim();
      if(!W.primaryText && !W.headline){ toast('Escreva o texto ou o título do anúncio'); return false; }
    }
    return true;
  }

  function publish(){
    const total = totalBudget();
    if(total<MIN_MT){ toast('Mínimo para anunciar: $2 USD ('+money(MIN_MT)+')'); return; }
    if(balance(S.user.id)<total){ toast('Saldo insuficiente — adicione saldo na Carteira'); return; }
    const e=estimate(total, W.cpc);
    const d=db();
    const camp={
      id:uid('c'), userId:S.user.id,
      name:W.name, objective:W.objectiveTitle, objectiveId:W.objective,
      specialCategory:W.specialCategory,
      platforms:W.platforms.slice(),
      placementMode:W.placementMode,
      placements:W.placementMode==='auto'?['Automático']:W.placements.slice(),
      gender:W.gender, minAge:W.minAge, maxAge:W.maxAge,
      locations:W.locations.slice(), interests:W.interests.slice(), language:W.language,
      budgetType:'daily', dailyBudget:W.dailyBudget, totalBudget:total, cpc:W.cpc,
      startDate:W.startDate||null, endDate:W.endDate||null,
      creative:{ format:W.format, primaryText:W.primaryText, headline:W.headline, description:W.description, cta:W.cta, websiteUrl:W.websiteUrl, mediaNote:W.mediaNote, whatsapp:W.whatsapp },
      status:'pendente',
      estimatedClicks:e.clicks, estimatedVisits:e.visits, estimatedSales:e.sales, estimatedImpressions:e.impressions,
      clicks:0, impressions:0, conversions:0,
      createdAt:new Date().toISOString()
    };
    d.campaigns.unshift(camp);
    d.txs.unshift({ id:uid('t'), userId:S.user.id, type:'campaign_payment', method:'balance', amount:total, reference:'camp_'+camp.id, status:'confirmed', createdAt:new Date().toISOString() });
    saveDb(d);
    pushNotif({ title:'Campanha criada', message:'"'+camp.name+'" enviada. Aguarda aprovação do admin.', type:'success', forUserId:S.user.id });
    pushNotif({ title:'Nova campanha pendente', message:S.user.name+': "'+camp.name+'" — '+total+' MT · '+W.objectiveTitle, type:'info', forAdmin:true });
    S.create=null;
    toast('Campanha enviada para aprovação');
    location.hash='campaigns';
  }

  show();
}

function viewAdmin(){
  if(!S.user||!S.user.isAdmin){ toast('Acesso negado'); location.hash='dashboard'; return; }
  document.getElementById('main').innerHTML=`
  <div class="card"><div class="h2">Administração</div>
  <div class="row">
    <button class="btn" id="tDep">Depósitos</button>
    <button class="btn secondary" id="tCamp">Campanhas</button>
    <button class="btn secondary" id="tSup">Suporte</button>
    <button class="btn secondary" id="tRec">Recuperar senha</button>
  </div>
  <div id="adm" style="margin-top:12px"></div></div>`;
  function deposits(){
    const list=db().txs.filter(t=>t.type==='deposit'&&t.status==='pending');
    let h=`<div class="h3">Depósitos pendentes (${list.length})</div>`;
    if(!list.length) h+='<p class="muted">Nenhum</p>';
    list.forEach(tx=>{
      const u=db().users.find(x=>x.id===tx.userId);
      h+=`<div class="card"><div class="between"><div><strong>${money(tx.amount)} · ${esc(tx.method)}</strong>
        <div class="muted">${esc(u&&u.name)} · ${esc(tx.payNumber)} ${esc(tx.payName)}</div></div><span class="badge pendente">Pendente</span></div>
        ${tx.proofData?`<img class="proof" src="${tx.proofData}"/>`:''}
        <div class="row" style="margin-top:8px">
          <button class="btn ok" data-a="approve" data-id="${tx.id}">Aprovar</button>
          <button class="btn danger" data-a="reject" data-id="${tx.id}">Rejeitar</button>
        </div></div>`;
    });
    document.getElementById('adm').innerHTML=h;
    document.getElementById('adm').querySelectorAll('[data-a]').forEach(b=>{
      b.onclick=()=>{
        const d=db(); const tx=d.txs.find(t=>t.id===b.dataset.id);
        if(!tx||tx.status!=='pending') return;
        if(b.dataset.a==='approve'){
          tx.status='confirmed';
          pushNotif({ title:'Depósito aprovado', message:`Depósito de ${tx.amount} MT aprovado. Saldo atualizado.`, type:'success', forUserId:tx.userId });
          toast('Aprovado — saldo creditado');
        } else {
          tx.status='rejected';
          pushNotif({ title:'Depósito rejeitado', message:`Depósito de ${tx.amount} MT rejeitado. Nada foi creditado.`, type:'danger', forUserId:tx.userId });
          toast('Rejeitado');
        }
        saveDb(d); deposits();
      };
    });
  }
  function camps(){
    const list=db().campaigns.filter(c=>c.status==='pendente');
    let h=`<div class="h3">Campanhas pendentes (${list.length})</div>`;
    if(!list.length) h+='<p class="muted">Nenhuma</p>';
    list.forEach(c=>{
      const u=db().users.find(x=>x.id===c.userId);
      h+=`<div class="card"><div class="between"><div><strong>${esc(c.name)}</strong><div class="muted">${esc(u&&u.name)} · ${money(c.totalBudget)} · CPC ${moneyUsd(c.cpc)}</div></div><span class="badge pendente">Pendente</span></div>
        <div class="row" style="margin-top:8px">
          <button class="btn ok" data-c="approve" data-id="${c.id}">Aprovar</button>
          <button class="btn danger" data-c="reject" data-id="${c.id}">Rejeitar</button>
        </div></div>`;
    });
    document.getElementById('adm').innerHTML=h;
    document.getElementById('adm').querySelectorAll('[data-c]').forEach(b=>{
      b.onclick=()=>{
        const d=db(); const c=d.campaigns.find(x=>x.id===b.dataset.id);
        if(!c) return;
        if(b.dataset.c==='approve'){
          c.status='active';
          const e=estimate(c.totalBudget,c.cpc);
          c.clicks=e.clicks; c.impressions=e.impressions; c.conversions=e.sales;
          pushNotif({ title:'Campanha aprovada', message:`"${c.name}" está ativa.`, type:'success', forUserId:c.userId });
        } else {
          c.status='rejeitada';
          d.txs.unshift({ id:uid('t'), userId:c.userId, type:'deposit', method:'reembolso', amount:c.totalBudget||0, reference:'refund_'+c.id, status:'confirmed', createdAt:new Date().toISOString() });
          pushNotif({ title:'Campanha rejeitada', message:`"${c.name}" rejeitada. Orçamento reembolsado.`, type:'danger', forUserId:c.userId });
        }
        saveDb(d); toast('Atualizado'); camps();
      };
    });
  }
  function support(){
    const msgs=db().support.filter(m=>m.toAdmin&&m.fromUser);
    let h=`<div class="h3">Mensagens de suporte (${msgs.length})</div>`;
    if(!msgs.length) h+='<p class="muted">Sem mensagens</p>';
    msgs.forEach(m=>{
      h+=`<div class="card"><strong>${esc(m.userName)}</strong> <span class="muted">${esc(m.userEmail)}</span>
        <p style="margin:6px 0">${esc(m.text)}</p>
        <div class="row"><input id="re_${m.id}" placeholder="Responder..." style="flex:1;margin:0"/><button class="btn" data-u="${m.userId}" data-mid="${m.id}">Enviar</button></div></div>`;
    });
    document.getElementById('adm').innerHTML=h;
    document.getElementById('adm').querySelectorAll('[data-u]').forEach(b=>{
      b.onclick=()=>{
        const text=document.getElementById('re_'+b.dataset.mid).value.trim();
        if(!text) return;
        const d=db();
        d.support.unshift({ id:uid('s'), userId:b.dataset.u, text, fromUser:false, fromAdmin:true, fromBot:false, createdAt:new Date().toISOString() });
        saveDb(d);
        pushNotif({ title:'Resposta do suporte', message:text.slice(0,120), type:'info', forUserId:b.dataset.u });
        toast('Enviado'); support();
      };
    });
  }
  function recoveries(){
    const list=(db().recoveries||[]).slice().sort((a,b)=> (b.createdAt||'').localeCompare(a.createdAt||''));
    let h=`<div class="h3">Pedidos de recuperação (${list.length})</div>`;
    if(!list.length) h+='<p class="muted">Nenhum pedido</p>';
    list.forEach(r=>{
      const u=db().users.find(x=>x.id===r.userId);
      const name=r.userName||(u&&u.name)||'—';
      const phone=r.userPhone||(u&&u.phone)||'—';
      const valid=r.status==='pending' && r.expires>Date.now();
      const st=r.status==='used'?'Usado':(!valid&&r.status==='pending'?'Expirado':r.status==='pending'?'Pendente':r.status);
      const base=location.href.split('#')[0];
      const link=base+'#reset-'+r.token;
      h+=`<div class="card">
        <div class="between"><div>
          <strong>${esc(name)}</strong>
          <div class="muted">${esc(r.email)} · ${esc(phone)}</div>
          <div class="muted">${r.createdAt?new Date(r.createdAt).toLocaleString('pt'):''}</div>
        </div><span class="badge ${r.status==='pending'&&valid?'pendente':''}">${st}</span></div>
        ${valid?`<p class="muted" style="margin:8px 0;font-size:11px;word-break:break-all">${esc(link)}</p>
        <div class="row">
          <button class="btn" data-copy="${esc(link)}">Copiar link</button>
          <button class="btn secondary" data-mail="${esc(r.email)}" data-link="${esc(link)}" data-name="${esc(name)}">Abrir e-mail</button>
          <button class="btn ok" data-open="${r.token}">Abrir reset</button>
        </div>`:'<p class="muted" style="margin-top:8px">Pedido já usado ou expirado</p>'}
      </div>`;
    });
    document.getElementById('adm').innerHTML=h;
    document.getElementById('adm').querySelectorAll('[data-copy]').forEach(b=>{
      b.onclick=async()=>{
        try{ await navigator.clipboard.writeText(b.dataset.copy); toast('Link copiado'); }
        catch(e){ toast('Copie manualmente o link'); }
      };
    });
    document.getElementById('adm').querySelectorAll('[data-mail]').forEach(b=>{
      b.onclick=()=>{
        const subject=encodeURIComponent('Native Ads Pay — Link para recuperar senha');
        const body=encodeURIComponent('Olá '+b.dataset.name+',\n\nSegue o link para redefinir a sua senha:\n\n'+b.dataset.link+'\n\nNative Ads Pay');
        window.location.href='mailto:'+encodeURIComponent(b.dataset.mail)+'?subject='+subject+'&body='+body;
      };
    });
    document.getElementById('adm').querySelectorAll('[data-open]').forEach(b=>{
      b.onclick=()=>{ location.hash='reset-'+b.dataset.open; };
    });
  }
  document.getElementById('tDep').onclick=deposits;
  document.getElementById('tCamp').onclick=camps;
  document.getElementById('tSup').onclick=support;
  document.getElementById('tRec').onclick=recoveries;
  deposits();
}

function botReply(text){
  const q=String(text||'').toLowerCase();
  if(q.includes('saldo')||q.includes('mpesa')||q.includes('e-mola')||q.includes('depósito')||q.includes('deposito'))
    return 'Para adicionar saldo: Carteira → Adicionar saldo → M-Pesa ou e-Mola → pague e anexe o screenshot. O admin aprova.';
  if(q.includes('campanha')||q.includes('aprova')||q.includes('pendente'))
    return 'As campanhas ficam Pendente até o administrador aprovar ou rejeitar.';
  if(q.includes('preço')||q.includes('cpc')||q.includes('clique')||q.includes('orçamento'))
    return 'O CPC varia entre $0,30 e $1,00 USD. O orçamento da carteira é em MT. No criar campanha vê a estimativa de cliques, visitas e vendas.';
  if(q.includes('olá')||q.includes('ola')||q.includes('bom dia')||q.includes('boa tarde'))
    return 'Olá! Sou o assistente Native Ads Pay. Como posso ajudar?';
  return 'Posso ajudar com saldo, campanhas ou orçamento. Para falar com um humano, use o botão "Falar com humano".';
}

function viewSupport(){
  S.supportMode=S.supportMode||'bot';
  document.getElementById('main').innerHTML=`
  <div class="card"><div class="h2">Suporte</div>
  <div class="row"><button class="btn" id="mBot">Chatbot</button><button class="btn secondary" id="mHum">Falar com humano</button></div>
  <div class="chat-box" id="chat"></div>
  <div class="row"><input id="sIn" style="flex:1;margin:0" placeholder="Mensagem..."/><button class="btn" id="sSend">Enviar</button></div>
  <p class="muted" id="sHint" style="margin-top:8px"></p></div>`;
  function load(){
    document.getElementById('sHint').textContent=S.supportMode==='bot'?'Modo chatbot':'Mensagens vão para o administrador';
    const msgs=db().support.filter(m=>m.userId===S.user.id||m.toUserId===S.user.id).slice().reverse();
    const box=document.getElementById('chat');
    box.innerHTML=msgs.map(m=>{
      const mine=m.fromUser;
      const who=mine?'Você':m.fromBot?'Bot':'Suporte';
      return `<div class="msg ${mine?'me':'bot'}"><div class="bubble"><div class="muted">${who}</div>${esc(m.text)}</div></div>`;
    }).join('')||'<p class="muted">Sem mensagens</p>';
    box.scrollTop=box.scrollHeight;
  }
  document.getElementById('mBot').onclick=()=>{ S.supportMode='bot'; load(); };
  document.getElementById('mHum').onclick=()=>{ S.supportMode='human'; load(); };
  document.getElementById('sSend').onclick=()=>{
    const text=document.getElementById('sIn').value.trim(); if(!text) return;
    const d=db();
    d.support.unshift({ id:uid('s'), userId:S.user.id, userName:S.user.name, userEmail:S.user.email, text, fromUser:true, toAdmin:S.supportMode==='human', fromBot:false, createdAt:new Date().toISOString() });
    if(S.supportMode==='bot'){
      d.support.unshift({ id:uid('s'), userId:S.user.id, text:botReply(text), fromUser:false, fromBot:true, createdAt:new Date().toISOString() });
    } else {
      pushNotif({ title:'Nova mensagem de suporte', message:`${S.user.name}: ${text.slice(0,100)}`, type:'info', forAdmin:true });
      d.support.unshift({ id:uid('s'), userId:S.user.id, text:'Mensagem enviada ao administrador. Responderá em breve.', fromUser:false, fromBot:true, createdAt:new Date().toISOString() });
    }
    saveDb(d); document.getElementById('sIn').value=''; load();
  };
  load();
}

function viewNotifications(){
  let list=db().notifs;
  if(S.user.isAdmin) list=list.filter(n=>n.forAdmin||!n.forUserId);
  else list=list.filter(n=>!n.forAdmin&&(!n.forUserId||n.forUserId===S.user.id));
  let h='<div class="card"><div class="h2">Notificações</div>';
  if(!list.length) h+='<p class="muted">Sem notificações</p>';
  list.forEach(n=>{
    h+=`<div class="card"><strong>${esc(n.title)}</strong><div class="muted">${esc(n.type)} · ${new Date(n.createdAt).toLocaleString('pt')}</div><p style="margin-top:4px">${esc(n.message)}</p></div>`;
  });
  h+='</div>';
  document.getElementById('main').innerHTML=h;
}

function viewProfile(){
  document.getElementById('main').innerHTML=`
  <div class="card"><div class="h2">Perfil</div>
  <label class="field-label">Nome</label><input id="pName" value="${esc(S.user.name)}"/>
  <label class="field-label">Telefone</label><input id="pPhone" value="${esc(S.user.phone)}"/>
  <label class="field-label">E-mail</label><input id="pEmail" value="${esc(S.user.email)}"/>
  <p class="muted" style="margin:8px 0">Armazenamento: ${Store.mode()}</p>
  <button class="btn" id="saveP">Salvar</button></div>`;
  document.getElementById('saveP').onclick=()=>{
    const d=db(); const u=d.users.find(x=>x.id===S.user.id);
    if(u){ u.name=document.getElementById('pName').value.trim(); u.phone=document.getElementById('pPhone').value.trim();
      const em=document.getElementById('pEmail').value.trim(); if(em.toLowerCase()!==ADMIN_EMAIL) u.email=em;
      saveDb(d); S.user=u; toast('Guardado'); }
  };
}

function route(){
  let h=(location.hash||'#login').replace('#','')||'login';
  // reset-<token>
  let resetToken=null;
  if(h.startsWith('reset-')){ resetToken=h.slice(6); h='reset'; }
  document.querySelectorAll('#menu a').forEach(a=>a.classList.toggle('active',a.dataset.r===h));
  S.user=currentUser();
  const publicPages=['login','register','recover','reset'];
  if(!S.user && !publicPages.includes(h)){ location.hash='login'; return; }
  if(S.user && ['login','register','recover','reset'].includes(h)){ location.hash=S.user.isAdmin?'admin':'dashboard'; return; }
  setAuthUI();
  if(h==='reset'){ viewReset(resetToken); return; }
  const map={ login:viewLogin, register:viewRegister, recover:viewRecover, dashboard:viewDashboard, wallet:viewWallet,
    transactions:viewTransactions, campaigns:viewCampaigns, create:viewCreate,
    admin:viewAdmin, support:viewSupport, notifications:viewNotifications, profile:viewProfile };
  (map[h]||viewDashboard)();
}

document.getElementById('menuBtn').onclick=()=>{
  document.getElementById('sidebar').classList.add('open');
  const o=document.createElement('div'); o.className='overlay'; o.id='ov';
  o.onclick=()=>{ document.getElementById('sidebar').classList.remove('open'); o.remove(); };
  document.body.appendChild(o);
};
document.getElementById('closeSb').onclick=()=>{ document.getElementById('sidebar').classList.remove('open'); const o=document.getElementById('ov'); if(o)o.remove(); };
document.getElementById('logoutBtn').onclick=e=>{ e.preventDefault(); logout(); setAuthUI(); location.hash='login'; toast('Sessão terminada'); };
document.querySelectorAll('#menu a[data-r]').forEach(a=>{
  a.onclick=e=>{ e.preventDefault(); location.hash=a.dataset.r; document.getElementById('sidebar').classList.remove('open'); const o=document.getElementById('ov'); if(o)o.remove(); };
});
window.addEventListener('hashchange', route);
ensureAdmin();
S.user=currentUser();
setAuthUI();
if(!location.hash) location.hash=S.user?(S.user.isAdmin?'admin':'dashboard'):'login';
else route();
